namespace Logic.Customers
{
    public enum LicensingModel
    {
        TwoDays = 1,
        LifeLong = 2
    }
}
