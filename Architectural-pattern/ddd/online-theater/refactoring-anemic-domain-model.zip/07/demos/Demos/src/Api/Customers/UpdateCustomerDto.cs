﻿namespace Api.Customers
{
    public class UpdateCustomerDto
    {
        public string Name { get; set; }
    }
}
