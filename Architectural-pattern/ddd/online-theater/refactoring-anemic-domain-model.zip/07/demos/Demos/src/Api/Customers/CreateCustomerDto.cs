﻿namespace Api.Customers
{
    public class CreateCustomerDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
