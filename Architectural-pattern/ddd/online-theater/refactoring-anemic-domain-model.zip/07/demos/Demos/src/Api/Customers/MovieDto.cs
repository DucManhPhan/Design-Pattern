﻿namespace Api.Customers
{
    public class MovieDto
    {
        public long Id { get; set; }
        public string Name { get; set; }
    }
}