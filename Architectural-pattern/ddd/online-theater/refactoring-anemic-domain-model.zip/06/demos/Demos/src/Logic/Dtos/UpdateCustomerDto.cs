﻿namespace Logic.Dtos
{
    public class UpdateCustomerDto
    {
        public string Name { get; set; }
    }
}
