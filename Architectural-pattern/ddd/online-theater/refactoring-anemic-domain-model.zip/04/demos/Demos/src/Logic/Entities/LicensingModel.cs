namespace Logic.Entities
{
    public enum LicensingModel
    {
        TwoDays = 1,
        LifeLong = 2
    }
}
