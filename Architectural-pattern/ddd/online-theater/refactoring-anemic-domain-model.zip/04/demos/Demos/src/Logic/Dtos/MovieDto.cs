﻿namespace Logic.Dtos
{
    public class MovieDto
    {
        public long Id { get; set; }
        public string Name { get; set; }
    }
}