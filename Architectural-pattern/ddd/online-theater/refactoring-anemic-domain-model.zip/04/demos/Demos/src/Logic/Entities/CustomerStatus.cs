﻿namespace Logic.Entities
{
    public enum CustomerStatus
    {
        Regular = 1,
        Advanced = 2
    }
}
